// ---------------------------------------------------------------------------------------------------------------------
//                                      Gabriel Malone / Week 3 / Lab 3 / CS 210
// ---------------------------------------------------------------------------------------------------------------------
#include 		<stdio.h>
#include 		<stdlib.h>
#include 		<stdint.h>
#include 		<stdbool.h>
// function prototypes // ----------------------------------------------------------------------------------------------
unsigned short	reverse_bytes(unsigned short);
unsigned short	booths_algorithm(uint8_t, uint8_t);
unsigned short	full_adder(uint8_t, uint8_t);
unsigned int	reverse_words(unsigned int);
unsigned int	ascii_to_integer(char*, int size);
char*			_to_bits(unsigned int);
void 			to_upper(char*, int size);
void 			to_lower(char*, int size);
void            bits(unsigned int);
void            print_bits(char*);
void            prt_st(char*, int);
void            pt_asc_bn(char* asc_num);
// vars for the lab methods // -----------------------------------------------------------------------------------------
uint8_t         a = 10;
uint8_t         b = 25;
unsigned short  prd;
unsigned short  sum;
char            asc_num [] = "123";
char            strA [] = "abc";
char            strB [] = "DOG";
int             asc;
unsigned int    x = 0xABCDEF00;
unsigned short  y = 0xABCD;

// ---------------------------------------------------------------------------------------------------------------------
//
//                                                      MAIN
//
// ---------------------------------------------------------------------------------------------------------------------
int main(int argc, char** argv){
// ---------------------------------------------------------------------------------------------------------------------
	// CONVERTING ASCII TO INTEGER DEMO
	// -----------------------------------------------------------------------------------------------------------------
	printf("\nascii '"); prt_st(asc_num, 3); printf("' in binary: "); pt_asc_bn(asc_num);
	printf("\nto decimal: %d \nto binary:  ", asc = ascii_to_integer(asc_num, 3)); bits(asc); printf("\n\n");
	
	// -----------------------------------------------------------------------------------------------------------------
	// CONVERTING LOWER TO UPPERCASE DEMO
	// -----------------------------------------------------------------------------------------------------------------
	printf("string:   '"); prt_st(strA, 3); printf("' in binary: "); pt_asc_bn(strA); printf("\n");
	printf("to upper: '"); to_upper(strA, 3); prt_st(strA, 3); printf("' in binary: "); pt_asc_bn(strA); printf("\n\n");
	
	// -----------------------------------------------------------------------------------------------------------------
	// CONVERTING UPPER TO LOWER DEMO
	// -----------------------------------------------------------------------------------------------------------------
	printf("string:   '"); prt_st(strB, 3); printf("' in binary: "); pt_asc_bn(strB); printf("\n");
	printf("to lower: '"); to_lower(strB, 3); prt_st(strB, 3); printf("' in binary: "); pt_asc_bn(strB); printf("\n");
	
	// -----------------------------------------------------------------------------------------------------------------
	// REVERSING WORDS DEMO
	// -----------------------------------------------------------------------------------------------------------------
	printf("\ndword original hex: %X & binary: ", x); bits(x) ;
	printf("\ndword reversed hex: %X & binary: ", x = reverse_words(x)); bits(x) ; printf("\n");
	
	// -----------------------------------------------------------------------------------------------------------------
	// REVERSING BYTES DEMO
	// -----------------------------------------------------------------------------------------------------------------
	printf("\nshort wrd original hex: %X & binary: ", y); bits(y) ;
	printf("\nshort wrd reversed hex: %X & binary: ", y = reverse_bytes(y)); bits(y); printf("\n");
	
	// -----------------------------------------------------------------------------------------------------------------
	// FULL ADDER DEMO
	// -----------------------------------------------------------------------------------------------------------------
	sum = full_adder(a,b);
	printf("\n%d (",a);bits(a);printf(") + %d (",b);bits(b);printf(") = %d",sum);printf(" (");bits(sum);printf(")");
	
	// -----------------------------------------------------------------------------------------------------------------
	// BOOTHS DEMO
	// -----------------------------------------------------------------------------------------------------------------
	prd = booths_algorithm(a,b);
	printf("\n\n%d (",a);bits(a);printf(") * %d (",b);bits(b);printf(") = %d",prd);printf(" (");bits(prd);printf(")\n");
}
// ---------------------------------------------------------------------------------------------------------------------
//
//                                                      METHODS
//
// ---------------------------------------------------------------------------------------------------------------------

// MIRROR WORD ORDER
// ---------------------------------------------------------------------------------------------------------------------
unsigned int reverse_words(unsigned int dword){ 													
	// -----------------------------------------------------------------------------------------------------------------
	return ( (dword & 0x0000FFFF) << 16) + ( (dword & 0xFFFF0000) >> 16); // dword & LO mask << to HO pos and vice-versa
}
// MIRROR BYTE ORDER
// ---------------------------------------------------------------------------------------------------------------------
unsigned short reverse_bytes(unsigned short word){
	// -----------------------------------------------------------------------------------------------------------------
	return ( (word & 0x00FF) << 8) + ( (word & 0xFF00) >> 8);              // word & LO mask << to HO pos and vice-versa
}
// MULTIPLY VIA BOOTHS ALGORITHM 
// ---------------------------------------------------------------------------------------------------------------------
unsigned short booths_algorithm(uint8_t mcnd, uint8_t mplr){
	// -----------------------------------------------------------------------------------------------------------------
	unsigned short itr = 0, PB = 0, CB = mplr & 1, LO = mplr, HO=0,product = 0x0000, phb;
	while (itr ++ < 8)                                                                        // need to loop for 8 bits
	{
		if (CB ^ PB)                                                                           // if xor results in true
		{                                                                             // add multiplicand to the HO byte
			if (CB)   HO = full_adder(HO, full_adder(~mcnd, 1));             // twos compliment addition for subtraction
			if (PB)   HO = full_adder(HO, mcnd);                                                             // addition
		}
		product = (HO << 8) | LO;    // new product is HO byte shifted into 16 bit position, w multiplier in LO position
		PB = product & 1;                                                                      // store previous end bit
		phb = product & 0x8000;                            // check if highest bit is 0 or 1 before shifting to maintain
		product >>= 1;                                                                 // shift product to the right one
		if (phb) product |= 0x8000;                                                 // force HO to 1 if originally was 1
		CB = product & 1;                                                                         // get current end bit
		HO = product >> 8;                                               // set new HO byte (the HO byte of the product)
		LO = product & 0x00FF;                                                                        // set new LO byte
	}
	return product;
}
// CONVERT ASCI TO INTEGER AND PRINT RESULTS
// ---------------------------------------------------------------------------------------------------------------------
unsigned int ascii_to_integer(char *ascii_number, int size){
	//------------------------------------------------------------------------------------------------------------------
	unsigned int converted = 0x00000000;
	for (int i = 0 ; i < size ; i ++ ) {       // clear HO 11's then convert each number to its correct decimal position
		print_bits(ascii_number);
		converted = converted * 10 + ( *ascii_number ++ &= ~( 3 << 4 ) );
	}                                                   // 0 + 1 = 1 * 10 = 10, 10 + 2 = 12, 12*10 = 120 + 3 = 123, etc.
	return converted;  // then set to 0 to clear those bits with &. the result is multiplied by current base 10 position
}
// CONVERT ASCII TO UPPER CASE
// ---------------------------------------------------------------------------------------------------------------------
void to_upper(char* d, int size){
	// -----------------------------------------------------------------------------------------------------------------
	for (int i = 0 ; i < size ; i ++)  *d ++ &= ~ ( 1 << 5 );                                                
								   // set 1, move it into position, flip it to zero, and the bit with that zero to clear
}
// CONVERT ASCII TO LOWER CASE 
// ---------------------------------------------------------------------------------------------------------------------
void to_lower(char* c, int size){
	// -----------------------------------------------------------------------------------------------------------------
	for (int i = 0 ; i < size ; i ++) *c ++ |= 1 << 5;   // set 1 , move to position , or the 1 with the bit to set to 1
}
// ADD VIA LOGIC GATES
// ---------------------------------------------------------------------------------------------------------------------
unsigned short full_adder(uint8_t one, uint8_t two) {
	// -----------------------------------------------------------------------------------------------------------------
	int      shift = 0;
	uint8_t  carry = 0;
	uint16_t sum   = 0;                                                          // Store 8-bit sum + carry-out in bit 8
	// -----------------------------------------------------------------------------------------------------------------
	while (shift < 8) {                                                                         // go through all 8 bits
		uint8_t x = (one >> shift) & 1;                                                            // start from LO bits
		uint8_t y = (two >> shift) & 1;                                                            // start from LO bits
		uint8_t sum_bit = x ^ y ^ carry;                  // sum_bit is 1 when there's an odd number of 1s in the inputs
		carry = (x & y) | (x & carry) | (y & carry);                 // carry-out exists if at least 2 of 3 inputs are 1
		sum |= (sum_bit << shift ++ );        // set the current bit with the sum_bit then increment shift for next loop
	}
	return sum |= (carry << 8);                                 // when done, store any carry-out in the 9th bit (bit 8)
}
// 'PRIVATE' TO BITS
// ---------------------------------------------------------------------------------------------------------------------
char *_to_bits(unsigned int num){
	// -----------------------------------------------------------------------------------------------------------------
	char* bits = malloc(sizeof(unsigned int) * sizeof(char) + 4);  // 4 for int and 1for char and 4 for spaces = 36 bits
	int shifts = 0;                                                 // how many shifts will be performed (32, 1 per bit)
	int cntr = 0;                                                                                       // space counter
	int idx = 0;                                                                                // overall index counter
	bool spacetime = false;
	// -----------------------------------------------------------------------------------------------------------------
	while (idx ++ < 36) {                                                                       // loop through each bit
		if (cntr ++ == 4) spacetime = true , cntr = 0, *bits++ = '_';                // place underscore when right time
		if (! spacetime) *bits++ = (num & 1 << shifts++) ? '1' : '0';                      // if ! underscore time 1s 0s
		spacetime = false;                                                                  // reset to false each round
	}
	// -----------------------------------------------------------------------------------------------------------------
	return bits;                                                        // return the pointer (will need to be re-wound)
}

// ---------------------------------------------------------------------------------------------------------------------
//                                                    extra helpers
// ---------------------------------------------------------------------------------------------------------------------

// PRINT BITS, PRINT BINARY CHAR ARRAY WITHOUT LEADING ZEROS
// ---------------------------------------------------------------------------------------------------------------------
void print_bits(char* ptr){
	// -----------------------------------------------------------------------------------------------------------------
	bool start = false;
	while (*--ptr) {
		if (*ptr == '1') start = true;                                                           // remove leading zeros
		if (start) printf("%c", *ptr);
	}
}
// PRINT A CHAR ARRAY 
// ---------------------------------------------------------------------------------------------------------------------
void prt_st(char* string, int size){
	// -----------------------------------------------------------------------------------------------------------------
	for (int i = 0 ; i < size ; i ++) (i == 0) ? printf("%c", string[i]) : printf("%c", string[i]);
}
// 'PUBLIC' TO BITS METHOD, CONVERT AND PRINT DATA TYPES TO BINARY CHAR ARRAY
// ---------------------------------------------------------------------------------------------------------------------
void bits(unsigned int num) {
	// -----------------------------------------------------------------------------------------------------------------
	char *binary = _to_bits(num);                                                      // enter any number up to 32 bits
	print_bits(binary);
	binary -= 36;               // point the pointer back to the start and free that point otherwise my strings build up
	free(binary);                                                // need to free this since it was allocated with malloc
}
// CONVERT AN ASCII INTEGER TO ITS BINARY REPRESENTATION 
// ---------------------------------------------------------------------------------------------------------------------
void pt_asc_bn(char* asc_num){
	// -----------------------------------------------------------------------------------------------------------------
	int idx = 0;
	while (asc_num[idx])
	{
		bits(*asc_num + idx ++); printf(" ");
	}
}
